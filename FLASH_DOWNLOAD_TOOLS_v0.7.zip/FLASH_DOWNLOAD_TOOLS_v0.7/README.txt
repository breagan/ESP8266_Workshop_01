A tool used to change the firmware of MOD-WIFI-ESP8266 and MOD-WIFI-ESP8266-DEV. By default both boards come with client firmware. However, if you switch to server or if you switch to custom firmware and you want to use the client programs you would need to reload the firmware.

Each of the examples has a README.txt in its main folder.